package com.demo.controller;

public @interface PostMaping {

}
