package com.demo.SprongBootHello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprongBootHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
