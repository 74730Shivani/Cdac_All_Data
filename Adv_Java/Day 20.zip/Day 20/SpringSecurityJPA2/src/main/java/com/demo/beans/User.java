package com.demo.beans;

public class User {

}
