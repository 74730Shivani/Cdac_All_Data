package com.demo.service;

public class CustomUserDetails {

}
