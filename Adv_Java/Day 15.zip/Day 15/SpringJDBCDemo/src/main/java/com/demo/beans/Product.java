package com.demo.beans;

public class Product {

}
