package com.demo.dao;

public interface ProductDao {

}
